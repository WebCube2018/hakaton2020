package ru.rosseti.razionalization;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentTransaction;

import android.content.pm.ActivityInfo;
import android.os.Bundle;

public class MainActivity extends AppCompatActivity {

    FragmentTransaction fragmentTransaction;
    FragmentKeys fragmentKeys;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
        getSupportActionBar().hide();
        setContentView(R.layout.activity_main);
    }

    private void setButtonFragment() {
        fragmentTransaction = getSupportFragmentManager().beginTransaction();
        fragmentKeys = new FragmentKeys();
        fragmentTransaction.replace(R.id.mainFragment, fragmentKeys);

        // fragmentTransaction.addToBackStack(null);
        fragmentTransaction.commit();
    }
}