package ru.rosseti.razionalization.data;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.Vector;

import ru.rosseti.razionalization.R;

public class MyDocsAdapter extends RecyclerView.Adapter<MyDocsAdapter.MyDocsHolder> {

    Vector<DataMyDocs> dataMyDocs;

    public MyDocsAdapter(Vector<DataMyDocs> dataMyDocs) {
        this.dataMyDocs = dataMyDocs;
    }

    @NonNull
    @Override
    public MyDocsHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        View view = layoutInflater.inflate(R.layout.layout_mydocs, parent, false);
        return new MyDocsHolder(view);
    }

    @Override
    public int getItemCount() {
        return dataMyDocs.size();
    }

    @Override
    public void onBindViewHolder(@NonNull MyDocsHolder holder, int position) {
        DataMyDocs dMD = dataMyDocs.elementAt(position);
        holder.bind(dMD);
    }

    public class MyDocsHolder extends RecyclerView.ViewHolder {

        TextView text_reg;
        TextView text_data;
        TextView text_title;
        TextView text_name;
        TextView text_status;
        DataMyDocs dataMyDocs;

        public MyDocsHolder(@NonNull View itemView) {
            super(itemView);
            text_reg = (TextView) itemView.findViewById(R.id.text_reg);
            text_data = (TextView) itemView.findViewById(R.id.text_data);
            text_title = (TextView) itemView.findViewById(R.id.text_title);
            text_name = (TextView) itemView.findViewById(R.id.text_name);
            text_status = (TextView) itemView.findViewById(R.id.text_status);
        }

        public void bind(DataMyDocs dataMyDocs) {
            this.dataMyDocs = dataMyDocs;
            text_reg.setText("Рег. №" + dataMyDocs.getRegNum());
            text_data.setText(" от " + dataMyDocs.getData());
            text_title.setText(dataMyDocs.getTitle());
            // text_name.setText("(" + dataMyDocs.getName() + ")");
            text_name.setVisibility(View.GONE);
            switch (dataMyDocs.getStatus()) {
                case 0:
                    text_status.setText("Статус: Экспертиза");
                    break;
                case 1:
                    text_status.setText("Статус: Доработка");
                    break;
                case 2:
                    text_status.setText("Статус: Признано");
                    break;
                case 3:
                    text_status.setText("Статус: Внедрение");
                    break;
            }

        }
    }

}
