package ru.rosseti.razionalization.data;

/** Класс, хранящий информацию о документах. Подключается к базе данных
 * на сервере, работает с ней напрямую.
 * Также проводится локальная загрузка предыдущих данных и/или
 * буферизация (дамп) информации в случае отсутствия интернета
 */
public class DataMyDocs {
    /** Регистрационный номер */
    String regNum;
    /** Имя заявителя */
    String name;
    /** Описание проекта */
    String title;
    /* Дата подачи заявления */
    String data;
    /* Текущий статус */
    int status;

    /*

            Поля идентификации записи

    */

    public DataMyDocs(String regNum, String name, String title, String data, int status) {
        this.regNum = regNum;
        this.name = name;
        this.title = title;
        this.data = data;
        this.status = status;
    }

    public String getRegNum() {
        return regNum;
    }

    public void setRegNum(String regNum) {
        this.regNum = regNum;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getData() {
        return data;
    }

    public void setData(String data) {
        this.data = data;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }
}
