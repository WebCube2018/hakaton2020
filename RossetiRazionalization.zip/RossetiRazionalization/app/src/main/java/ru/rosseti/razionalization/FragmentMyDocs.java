package ru.rosseti.razionalization;

import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import java.util.Vector;

import ru.rosseti.razionalization.data.DataMyDocs;
import ru.rosseti.razionalization.data.MyDocsAdapter;

public class FragmentMyDocs extends Fragment {

    RecyclerView recyclerView;
    private MyDocsAdapter myDocsAdapter;

    Vector<DataMyDocs> dataMyDocs;

    public FragmentMyDocs() {
        dataMyDocs = new Vector<>();

        dataMyDocs.add(new DataMyDocs("E015-89", "Коноров О.А.", "Снижение оплаты коммунальных услуг.", "25/11/2020", 3));
        dataMyDocs.add(new DataMyDocs("E015-83", "Коноров О.А.", "Внедрение стереотипных линий электропередач.", "25/11/2020", 1));
        dataMyDocs.add(new DataMyDocs("E015-84", "Коноров О.А.", "Проверка остаточного напряжения на флиппелях актуматических систем.", "25/11/2020", 0));
        dataMyDocs.add(new DataMyDocs("E015-85", "Коноров О.А.", "Разработка новых ингредиентов-активаторов для создания композиционных материалов на основе каучуков специального и общего " +
                "назначения (конечный продукт: резинотехнические изделия (РТИ), шины) .", "25/11/2020", 2));
        dataMyDocs.add(new DataMyDocs("E015-86", "Коноров О.А.", "Проверка остаточного напряжения на флиппелях актуматических систем.", "25/11/2020", 3));
        dataMyDocs.add(new DataMyDocs("E015-87", "Коноров О.А.", "Оптимизация оценки затрат на оптимизацию оценки затрат.", "25/11/2020", 2));
        dataMyDocs.add(new DataMyDocs("E015-88", "Коноров О.А.", "Шлифовка узлов гидроагрегата средствами пылесборников УМД-382Б.", "25/11/2020", 1));
        dataMyDocs.add(new DataMyDocs("E015-90", "Коноров О.А.", "Расположение насосов для уменьшения электроподачи.", "25/11/2020", 3));
        dataMyDocs.add(new DataMyDocs("E017-95", "Коноров О.А.", "Быстрое развёртывание систем на базе А9.", "25/11/2020", 2));
        dataMyDocs.add(new DataMyDocs("E017-96", "Коноров О.А.", "Внедрение стереотипных линий электропередач.", "25/11/2020", 1));
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.layout_mydocs_fragment, container, false);
        recyclerView = (RecyclerView) view.findViewById(R.id.recyclerMyDocs);

        createAdapter();

        return view;
    }

    private void createAdapter() {
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        myDocsAdapter = new MyDocsAdapter(dataMyDocs);
        recyclerView.setAdapter(myDocsAdapter);
    }
}