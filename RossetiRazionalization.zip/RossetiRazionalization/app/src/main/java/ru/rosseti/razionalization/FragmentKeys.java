package ru.rosseti.razionalization;

import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.Toast;

import java.util.Objects;

public class FragmentKeys extends Fragment {
    public FragmentKeys() {
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.layout_key_fragment, container, false);
        Button button01 = (Button) view.findViewById(R.id.button01);
        Button button02 = (Button) view.findViewById(R.id.button02);
        Button button03 = (Button) view.findViewById(R.id.button03);
        Button button04 = (Button) view.findViewById(R.id.button04);
        Button button05 = (Button) view.findViewById(R.id.button05);
        Button button06 = (Button) view.findViewById(R.id.button06);

        button01.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(getActivity().getApplicationContext(), "Работает кнопка \"Мои предложения\"", Toast.LENGTH_SHORT).show();
            }
        });

        // МОИ ДОКУМЕНТЫ
        button02.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Fragment fragment = new FragmentMyDocs();
                // Менеджер
                FragmentManager fragmentManager = Objects.requireNonNull(getActivity().getSupportFragmentManager());
                FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
                fragmentTransaction.replace(R.id.mainFragment, fragment);
                // Добавляем работу кнопки назад
                fragmentTransaction.addToBackStack(null);
                fragmentTransaction.commit();
            }
        });

        button03.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(getActivity().getApplicationContext(), "Работает кнопка \"Мои предложения\"", Toast.LENGTH_SHORT).show();
            }
        });

        button04.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(getActivity().getApplicationContext(), "Работает кнопка \"Мои предложения\"", Toast.LENGTH_SHORT).show();
            }
        });

        button05.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(getActivity().getApplicationContext(), "Работает кнопка \"Мои предложения\"", Toast.LENGTH_SHORT).show();
            }
        });

        button06.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(getActivity().getApplicationContext(), "Работает кнопка \"Мои предложения\"", Toast.LENGTH_SHORT).show();
            }
        });

        return view;
    }
}